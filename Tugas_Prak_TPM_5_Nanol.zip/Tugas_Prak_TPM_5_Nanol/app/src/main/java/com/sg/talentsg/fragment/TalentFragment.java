package com.sg.talentsg.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sg.talentsg.R;
import com.sg.talentsg.adapter.TalentAdapter;
import com.sg.talentsg.data.TalentData;
import com.sg.talentsg.model.TalentModel;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class TalentFragment extends Fragment {

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.fragment_talent, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Talent SG");

        TalentAdapter TalentAdapter = new TalentAdapter(TalentData.generateTalent(),getContext());
        RecyclerView rvTalent = getView().findViewById(R.id.rv_talent_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        rvTalent.setLayoutManager(layoutManager);
        rvTalent.setHasFixedSize(true);
        rvTalent.setAdapter(TalentAdapter);
    }
}
