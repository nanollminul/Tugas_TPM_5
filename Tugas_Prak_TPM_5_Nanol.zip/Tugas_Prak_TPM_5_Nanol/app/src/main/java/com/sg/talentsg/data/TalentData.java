package com.sg.talentsg.data;

import com.sg.talentsg.model.TalentModel;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;

public final class TalentData {

    @NotNull
    public static ArrayList<TalentModel> generateTalent() {
        ArrayList<TalentModel> talent = new ArrayList<>();

        talent.add(new TalentModel(
            "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/48757a73-bc34-4da9-be45-0ba16c9e4728/dbom9l9-79bdf609-8bd8-4e18-a93d-3257e00ad190.jpg/v1/fill/w_600,h_787,q_75,strp/punk_vector_by_lcosmo_dbom9l9-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9Nzg3IiwicGF0aCI6IlwvZlwvNDg3NTdhNzMtYmMzNC00ZGE5LWJlNDUtMGJhMTZjOWU0NzI4XC9kYm9tOWw5LTc5YmRmNjA5LThiZDgtNGUxOC1hOTNkLTMyNTdlMDBhZDE5MC5qcGciLCJ3aWR0aCI6Ijw9NjAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.RQiQIouJLArcCm2zlcy-cmw9UtU4tOGoc58DiGinytk",
            "Frrswcksn",
            "Main",
            "Frrswcksn is the one fo the main-TalentSG.\n\nFrrswcksn litte bit crazy but issokey la. Frrswcksn is a very talented talent. One of the many people who likes to help unconditionally and a strong sense of friendship."
        ));
        talent.add(new TalentModel(
            "https://e7.pngegg.com/pngimages/231/596/png-clipart-boy-with-red-hat-illustratio-aceh-rumah-adat-animation-cartoon-doraemon-food-hat-thumbnail.png",
            "Sri",
            "Ngasor",
            "Such a great guy with a great many lessons of life. \n\nSri is a good leader also friend. "
        ));
        talent.add(new TalentModel(
            "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/3021adb2-10e5-4081-9d69-135bbdc1958b/ddt1g3l-019dc742-6b71-48d4-85a8-8f9e55508c29.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzMwMjFhZGIyLTEwZTUtNDA4MS05ZDY5LTEzNWJiZGMxOTU4YlwvZGR0MWczbC0wMTlkYzc0Mi02YjcxLTQ4ZDQtODVhOC04ZjllNTU1MDhjMjkuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.nLhfAWXXxqiilVR9CFMsb84AVTVKt3oC0O6CU7hDxpY",
            "Barbara",
            "Mediator",
            "The most honest ppl I ever known. \n\nLucky to have Barbara on your side, she is a amazing person I ever met"
        ));
        talent.add(new TalentModel(
            "https://img.pngio.com/eren-yeager-levi-mikasa-ackerman-sasha-braus-anime-png-clipart-levi-ackerman-png-728_781.jpg",
            "Bayt",
            "Kyuti",
            "Where ever and ever, he is a good listener. A cooperative partner."
        ));
        talent.add(new TalentModel(
            "https://img.wattpad.com/b09fdd8aa17b24a9f140de7267356cb3dc7df6f9/68747470733a2f2f73332e616d617a6f6e6177732e636f6d2f776174747061642d6d656469612d736572766963652f53746f7279496d6167652f454d457053574567455436555a413d3d2d3735393936393638392e313562323830626461663834326534633436313136323538333532342e6a7067?s=fit&w=720&h=720",
            "Pamungkas",
            "Initiator",
            "Fvckboy + Pamungkas = Great Combination."
        ));
        talent.add(new TalentModel(
            "https://i.pinimg.com/564x/db/1e/29/db1e29c7ba309d373c313ff6f2810a7d.jpg",
            "Weebs",
            "Core",
            "Arek wetan."
        ));
        talent.add(new TalentModel(
            "https://w7.pngwing.com/pngs/793/373/png-transparent-james-p-sullivan-monsters-inc-mike-sulley-to-the-rescue-mike-wazowski-monster-university-sullivan-blue-snout-pixar.png",
            "Tohil",
            "Pleaseful",
             "Tohil is a good listener, although there are certain annoyances. never tired to help and hear us tell stories."
        ));
        talent.add(new TalentModel(
            "https://static.wikia.nocookie.net/valorant/images/7/79/Jett_artwork.png/revision/latest?cb=20200602020209",
            "Ndarjo",
            "Photographer",
            "From Korea comes Jett, an agile fighter who prioritizes movement over everything. Her abilities include a teleportation-based dash and an updraft that lets her reach higher ledges. She also has a smokebomb ability to hinder sightlines and a powerful Bladestorm ultimate that deals moderate-to-heavy damage and remains accurate even while she's moving. \n\nJett is one of the few Agents with a passive ability. Holding the jump key while in the air will allow Jett to slow her descent. \n\nJett's Ultimate allows her to wield several throwing knives that deal moderate damage and kill on headshots. Getting a kill replenishes your daggers and you can choose to throw them one at a time or throw all remaining daggers in a short-ranged burst."
        ));
        talent.add(new TalentModel(
            "https://www.pinclipart.com/picdir/middle/1-12651_view-all-images-1-hard-worker-icon-png.png",
            "Nypeee",
            "The Diligent one",
            "Shining Klaten."
        ));
        talent.add(new TalentModel(
            "https://koran-jakarta.com/images/article/phpb3iw8__resized.jpg",
            "Bocil",
            "Annoy-one",
            "Dear Nathan, Hello Salma."
        ));
        talent.add(new TalentModel(
            "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/fb39ee1e-a23d-4be4-84a4-1d6da4e4f973/dcfcef5-daeb17f7-0f01-4aad-a165-3f701003cf5f.png/v1/fill/w_1024,h_1449,strp/nana_mobile_legends_by_afrisf_dcfcef5-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTQ0OSIsInBhdGgiOiJcL2ZcL2ZiMzllZTFlLWEyM2QtNGJlNC04NGE0LTFkNmRhNGU0Zjk3M1wvZGNmY2VmNS1kYWViMTdmNy0wZjAxLTRhYWQtYTE2NS0zZjcwMTAwM2NmNWYucG5nIiwid2lkdGgiOiI8PTEwMjQifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.ZxkHJOvN6oRHZVgwgL30eaLsthmz5no-LMxpGMcySso",
            "Sky",
            "Bcddd",
            "Thank you for every single name that I mentioned in this task. Love you all."
        ));
        talent.add(new TalentModel(
            "https://statik.tempo.co/data/2017/12/07/id_668041/668041_720.jpg",
            "Prince of Rohadi",
            "Silencer",
            "Amin yang beda"
        ));


        return talent;
    }
}
