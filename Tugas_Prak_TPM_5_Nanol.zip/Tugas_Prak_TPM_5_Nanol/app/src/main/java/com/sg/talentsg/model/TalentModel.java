package com.sg.talentsg.model;

public class TalentModel {
    private String image,name,role,summary;

    public TalentModel(String image, String name, String role, String summary) {
        this.image   = image;
        this.name    = name;
        this.role    = role;
        this.summary = summary;
    }

    public String getImage() {
        return image;
    }
    public String getName() {
        return name;
    }
    public String getRole() {
        return role;
    }
    public String getSummary() {
        return summary;
    }
}
